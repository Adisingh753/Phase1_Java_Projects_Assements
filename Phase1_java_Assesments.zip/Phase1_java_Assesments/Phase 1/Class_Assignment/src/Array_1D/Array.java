package Array_1D;

public class Array {
	
	public static void main(String[] args) {	
          int A[] = {7, 6, 3, 4};
          int B[] = {4, 9, 7, 2};
          int C[] = new int [4];
          
        for (int i = 0; i < A.length; i++) {
        	System.out.print(C[i] = A[i] + B[i]);
        	System.out.print(" ");
        }      
	}
}
