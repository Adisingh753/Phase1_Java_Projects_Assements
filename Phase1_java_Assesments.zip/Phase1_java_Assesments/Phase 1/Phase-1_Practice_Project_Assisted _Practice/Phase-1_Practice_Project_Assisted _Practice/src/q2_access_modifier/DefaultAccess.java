package q2_access_modifier;

public class DefaultAccess {
	static void Logger(){
        System.out.println("This is default");
    }
	public static void main (String [] args) {
		
		Logger();
	}
}
